import json
import pandas as pd
from prophet import Prophet
from src.utils import get_network_type_counts
from src.config import CONFIG

# Pattern Detection Function
def detect_patterns(group):
    time_pattern = None
    day_pattern = None
    network_pattern = None
    session_pattern = None
    subnet_pattern = None
    prophet_pattern = None

    # Time Pattern
    if 'Start Time' in group:
        hours = pd.to_datetime(group['Start Time']).dt.hour
        if ((hours >= 9) & (hours <= 11)).sum() / len(group) > 0.5:
            time_pattern = "High anomalies during 09:00-11:00"

    # Day Pattern
    days = pd.to_datetime(group['Date']).dt.day_name()
    common_day = days.value_counts().idxmax()
    if days.value_counts().max() / len(group) > 0.5:
        day_pattern = f"Frequent issues on {common_day}"

    # Network Pattern
    network = group['Second Network Connection Detail'].value_counts(normalize=True)
    if 'Wifi' in network and network['Wifi'] > 0.6:
        network_pattern = "Over 60% anomalies involve Wifi"

    # Session Type Pattern
    session = group['Session Type'].value_counts(normalize=True)
    if session.max() > 0.8:
        session_pattern = f"{round(session.max()*100)}% anomalies in {session.idxmax()} calls"

    # Subnet Pattern
    if 'Second Subnet' in group:
        subnets = group['Second Subnet'].value_counts()
        if not subnets.empty:
            top_subnet = subnets.idxmax()
            subnet_pattern = f"Subnet {top_subnet} shows repeated issues"

    return {
        "TimePattern": time_pattern,
        "DayPattern": day_pattern,
        "NetworkPattern": network_pattern,
        "SessionTypePattern": session_pattern,
        "SubnetPattern": subnet_pattern
    }

# Prophet Seasonality Detection
def detect_seasonality_prophet(group):
    if len(group) < 5:
        return None  # insufficient data
    daily = group.groupby('Date').size().reset_index(name='y')
    daily.rename(columns={'Date': 'ds'}, inplace=True)
    model = Prophet(daily_seasonality=True)
    model.fit(daily)
    future = model.make_future_dataframe(periods=7)
    forecast = model.predict(future)
    seasonality = forecast[['ds', 'yhat']].sort_values(by='yhat', ascending=False).head(3)
    return seasonality['ds'].dt.strftime('%Y-%m-%d').tolist()

# Alert Generation Function
def generate_alerts(anomalies_df):
    alerts = []
    for ip, group in anomalies_df.groupby(lambda x: group_by_ip(anomalies_df.iloc[x]), sort=False):
        first_conn = get_network_type_counts(group['First Network Connection Detail'])
        second_conn = get_network_type_counts(group['Second Network Connection Detail'])

        patterns = detect_patterns(group)
        prophet_dates = detect_seasonality_prophet(group)

        alert = {
            "ReflexiveIP": ip,
            "TotalAnomalies_Last30Days": len(group),
            "AffectedSessionTypeCounts": group['Session Type'].value_counts().to_dict(),
            "UniqueFirstUPNs": group['First UPN'].dropna().unique().tolist(),
            "UniqueSecondUPNs": group['Second UPN'].dropna().unique().tolist(),
            "FirstNetworkConnectionType": first_conn,
            "SecondNetworkConnectionType": second_conn,
            "AvgJitter_Last30Days": round(group['AvgJitter'].mean(), 2),
            "AvgRTT_Last30Days": round(group['AvgRoundTripTime'].mean(), 2),
            "AvgPacketLoss_Last30Days": round(group['AvgPacketLoss'].mean(), 2),
            "DetectedPatterns": patterns,
            "ProphetForecastTopDates": prophet_dates
        }
        alerts.append(alert)
    return alerts

def group_by_ip(row):
    if row['Session Type'] == 'Conf':
        return row['Second Reflexive Local IP Network']
    else:
        return row['First Reflexive Local IP Network'] if pd.notnull(row['First Reflexive Local IP Network']) else row['Second Reflexive Local IP Network']

def save_alerts(alerts, output_file):
    with open(output_file, 'w') as f:
        json.dump(alerts, f, indent=4)
