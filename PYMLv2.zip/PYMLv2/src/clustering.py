from sklearn.cluster import KMeans
import pandas as pd

def perform_clustering(df):
    features = ['AvgJitter', 'AvgRoundTripTime', 'AvgPacketLoss']
    X = df[features].fillna(0)

    kmeans = KMeans(n_clusters=3, random_state=42)
    df['Cluster'] = kmeans.fit_predict(X)
    return df
