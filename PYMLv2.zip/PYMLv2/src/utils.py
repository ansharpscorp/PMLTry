def get_network_type_counts(series):
    return {
        "Wired": (series == "Wired").sum(),
        "Wifi": (series == "Wifi").sum(),
        "Unknown": series.isna().sum()
    }
