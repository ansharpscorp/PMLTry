from sklearn.ensemble import IsolationForest
import pandas as pd
from src.config import CONFIG

def detect_anomalies(df):
    anomalies_list = []

    for stype in CONFIG['session_type_analysis']:
        df_type = df[df['Session Type'] == stype].copy()

        if df_type.empty:
            continue

        features = ['AvgJitter', 'AvgRoundTripTime', 'AvgPacketLoss']
        X = df_type[features].fillna(0)

        if len(X) < 1:
            continue

        model = IsolationForest(contamination=0.05, random_state=42)
        df_type['Anomaly'] = model.fit_predict(X)
        df_type_ml = df_type[df_type['Anomaly'] == -1]

        manual_anomalies = df_type[
            (df_type['AvgJitter'] > 50) |
            (df_type['AvgRoundTripTime'] > 300) |
            (df_type['AvgPacketLoss'] > 2)
        ]
        manual_anomalies['Anomaly'] = -1

        combined = pd.concat([df_type_ml, manual_anomalies]).drop_duplicates()
        anomalies_list.append(combined)

    return pd.concat(anomalies_list, ignore_index=True) if anomalies_list else pd.DataFrame()
