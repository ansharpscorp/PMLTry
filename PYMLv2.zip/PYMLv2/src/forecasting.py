from prophet import Prophet
import pandas as pd

def forecast_anomalies(df):
    daily = df.groupby('Date').size().reset_index(name='y')
    daily.rename(columns={'Date': 'ds'}, inplace=True)

    model = Prophet(daily_seasonality=True)
    model.fit(daily)

    future = model.make_future_dataframe(periods=7)
    forecast = model.predict(future)
    return forecast[['ds', 'yhat']].tail(7)
