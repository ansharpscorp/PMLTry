import pandas as pd
from sqlalchemy import create_engine
from src.config import CONFIG

def load_data():
    if CONFIG['input_source'] == 'csv':
        return pd.read_csv(CONFIG['csv_file'])
    elif CONFIG['input_source'] == 'sql':
        engine = create_engine(CONFIG['sql']['connection_string'])
        return pd.read_sql(CONFIG['sql']['table_name'], engine)
    else:
        raise ValueError("Invalid input source")
