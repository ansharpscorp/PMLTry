CONFIG = {
    "input_source": "csv",  # or "sql"
    "csv_file": "data/sample_input.csv",
    "sql": {
        "connection_string": "mysql+pymysql://user:password@localhost/dbname",
        "table_name": "teams_call_data"
    },
    "session_type_analysis": ["P2P", "Conf"],
}
