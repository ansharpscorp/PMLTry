
def score_alert(alert):
    score = 0
    score += alert.get("UsersAffected", 0) * 2
    score += alert.get("AnomalyCount", 0) * 1.5
    score += len(alert.get("HighlyAffectedSubnets", {})) * 1.2
    score += len(alert.get("FeedbackAnalysis", {}).get("FeedbackTexts", [])) * 1.5
    score += alert.get("ConferencesWith>100Participants", 0) * 2
    return round(score, 2)
