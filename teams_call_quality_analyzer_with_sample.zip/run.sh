#!/bin/bash
python3 main.py --start_date "$1" --end_date "$2"