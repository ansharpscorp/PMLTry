import json
from analyzer.loader import load_data
from analyzer.processor import summarize_data
from analyzer.summarizer import generate_nlp_summary
from analyzer.shap_explainer import run_shap_analysis
import os

# Load config
with open("config.json") as f:
    config = json.load(f)

# Ensure output dir
os.makedirs(os.path.dirname(config["output_summary_csv"]), exist_ok=True)

# Load & process data
df = load_data(config)
summary_df = summarize_data(df, config)

# Add NLP story
summary_df['Story'] = summary_df.apply(lambda row: generate_nlp_summary(row, config), axis=1)

# Save to CSV
summary_df.to_csv(config["output_summary_csv"], index=False)
print(f"✔ Summary saved to {config['output_summary_csv']}")

# Run SHAP (optional visualization)
run_shap_analysis(df, config)
