anomaly_nlp_project/
├── config.json
├── main.py
├── output/
│   ├── summary.csv
│   └── shap_output/
├── analyzer/
│   ├── __init__.py
│   ├── loader.py
│   ├── processor.py
│   ├── summarizer.py
│   └── shap_explainer.py
