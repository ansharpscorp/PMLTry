import pandas as pd

def summarize_data(df, config):
    cols = config["columns"]

    grouped = df.groupby(cols["reflexive_ip"]).agg(
        TotalAlerts=(cols["conference_id"], 'count'),
        UniqueSubnets=(cols["subnet"], pd.Series.nunique),
        AffectedUsers=(cols["upn"], pd.Series.nunique),
        Anomalies=(cols["anomaly_reason"], lambda x: x.value_counts().to_dict())
    ).reset_index()

    return grouped
