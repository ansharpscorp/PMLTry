import shap
import pandas as pd
import xgboost
import os

def run_shap_analysis(df, config):
    cols = config["columns"]
    output_dir = config["shap_output_dir"]
    os.makedirs(output_dir, exist_ok=True)

    # Create a mock binary target just for SHAP explanation
    df['Target'] = 1  # Since these are all alerts
    features = pd.get_dummies(df[[cols["subnet"], cols["upn"], cols["anomaly_reason"]]].astype(str))

    model = xgboost.XGBClassifier(use_label_encoder=False, eval_metric='logloss')
    model.fit(features, df['Target'])

    explainer = shap.Explainer(model)
    shap_values = explainer(features)

    # Save SHAP plot
    shap.summary_plot(shap_values, features, show=False)
    shap.plots.bar(shap_values, show=False)
    print(f"✔ SHAP analysis complete. Check {output_dir}")
