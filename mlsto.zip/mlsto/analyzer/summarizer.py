def generate_nlp_summary(row, config):
    ip = row['Reflexive IP']
    alerts = row['TotalAlerts']
    subnets = row['UniqueSubnets']
    users = row['AffectedUsers']
    anomalies = ", ".join([f"{k}: {v}" for k, v in row['Anomalies'].items()])

    summary = (
        f"In the last {config['last_n_days']} days, Reflexive IP {ip} caused {alerts} alerts, "
        f"affecting {subnets} subnet(s) and {users} users. "
        f"Anomaly types observed: {anomalies}."
    )
    return summary
