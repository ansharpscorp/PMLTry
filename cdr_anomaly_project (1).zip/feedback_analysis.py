import nltk
from nltk.sentiment import SentimentIntensityAnalyzer

def analyze_feedback(df):
    sia = SentimentIntensityAnalyzer()
    df['feedback_sentiment'] = df['Second Feedback Text'].fillna('').apply(lambda t: sia.polarity_scores(t)['compound'])
    return df
