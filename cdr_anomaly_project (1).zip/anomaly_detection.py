from sklearn.ensemble import IsolationForest

def detect_anomalies(df, features):
    model = IsolationForest(n_estimators=100, contamination=0.01, random_state=42)
    df_clean = df.dropna(subset=features)
    model.fit(df_clean[features])
    df['anomaly'] = model.predict(df[features])
    return df
