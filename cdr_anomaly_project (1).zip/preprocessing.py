import pandas as pd
import numpy as np
from utils.ip_utils import extract_subnet
from utils.vdi_utils import map_vdi_version

ZERO_FILL_COLS = [
    'Total Stream Count', 'Audio Stream Count', 'Audio Poor Stream Count',
    'Video Stream Count', 'Video Poor Stream Count',
    'Total CDR Available Stream Count', 'Total Call Setup Failed Stream Count',
    'Total Call Setup Succeeded Stream Count', 'Total Call Dropped Stream Count',
    'Total Media Failed Stream Count',
    'Avg Jitter', 'Avg Jitter Max',
    'Avg Round Trip', 'Avg Round Trip Max',
    'Avg Packet Loss Rate', 'Avg Packet Loss Rate Max',
    'Avg Overall Avg Network MOS', 'Avg Packet Utilization'
]

def load_data(engine, start_date, end_date):
    query = f"""
    SELECT *
    FROM cdr_table
    WHERE [Date] BETWEEN '{start_date}' AND '{end_date}'
    """
    return pd.read_sql(query, engine)

def clean_data(df):
    df[ZERO_FILL_COLS] = df[ZERO_FILL_COLS].fillna(0)
    df.loc[~df['First Network Connection Detail'].isin(['Wired', 'Wifi']), 'First Network Connection Detail'] = np.nan
    df.loc[~df['Second Network Connection Detail'].isin(['Wired', 'Wifi']), 'Second Network Connection Detail'] = np.nan
    mask = ((df['Audio Poor Stream Count'] > 0) | (df['Video Poor Stream Count'] > 0)) & df['ClassifiedPoorCall'].isna()
    df.loc[mask, 'ClassifiedPoorCall'] = True
    df['Audio Poor Percentage'] = df['Audio Poor Stream Count'] / df['Audio Stream Count'].replace(0, np.nan)
    df['Video Poor Percentage'] = df['Video Poor Stream Count'] / df['Video Stream Count'].replace(0, np.nan)
    df['Call Dropped Percentage'] = df['Total Call Dropped Stream Count'] / df['Total CDR Available Stream Count'].replace(0, np.nan)
    df['Setup Failure Percentage'] = df['Total Call Setup Failed Stream Count'] / df['Total CDR Available Stream Count'].replace(0, np.nan)
    df['First VDI Version'] = df['First Client VDI Mode'].apply(map_vdi_version)
    df['Second VDI Version'] = df['Second Client VDI Mode'].apply(map_vdi_version)
    df['First Subnet'] = df.apply(lambda r: r['First Subnet'] if pd.notna(r['First Subnet']) else extract_subnet(r['First IP Address']), axis=1)
    df['Second Subnet'] = df.apply(lambda r: r['Second Subnet'] if pd.notna(r['Second Subnet']) else extract_subnet(r['Second IP Address']), axis=1)
    df[['First Subnet', 'Second Subnet']] = df[['First Subnet', 'Second Subnet']].fillna('Unknown')
    return df
