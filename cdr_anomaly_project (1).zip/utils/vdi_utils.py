def map_vdi_version(mode):
    mode = str(mode)
    if mode.startswith('11') or mode.startswith('21'):
        return 'VDI 1.0'
    if mode.startswith('12') or mode.startswith('22'):
        return 'VDI 2.0'
    return 'Unknown'
