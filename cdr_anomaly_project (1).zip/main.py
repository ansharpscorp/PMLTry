import argparse
from db_connection import get_synapse_engine
from preprocessing import load_data, clean_data
from anomaly_detection import detect_anomalies
from xgboost_model import train_xgb
from feedback_analysis import analyze_feedback
from alert_generator import AlertGenerator

FEATURES = ['Avg Jitter', 'Avg Round Trip', 'Avg Packet Loss Rate']
TARGET = 'ClassifiedPoorCall'

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--start_date', required=True)
    parser.add_argument('--end_date', required=True)
    args = parser.parse_args()

    engine = get_synapse_engine()
    df = load_data(engine, args.start_date, args.end_date)
    df = clean_data(df)

    df = detect_anomalies(df, FEATURES)
    xgb_model = train_xgb(df, FEATURES, TARGET)
    df = analyze_feedback(df)

    ag = AlertGenerator()
    ag.generate(df)
