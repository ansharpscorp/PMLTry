import xgboost as xgb

def train_xgb(df, features, target):
    dtrain = xgb.DMatrix(df[features], label=df[target])
    params = {
        'objective': 'binary:logistic',
        'eval_metric': 'auc'
    }
    model = xgb.train(params, dtrain, num_boost_round=100)
    return model
