from prophet import Prophet
import pandas as pd

def forecast_anomalies(df, ip_col='First Reflexive Local IP Network'):
    alerts = []
    for ip in df[ip_col].dropna().unique():
        sub_df = df[df[ip_col] == ip]
        daily = sub_df.groupby('Date').size().reset_index(name='y')
        if len(daily) < 5: continue  # skip if insufficient data
        
        daily.rename(columns={'Date': 'ds'}, inplace=True)
        model = Prophet(daily_seasonality=True)
        model.fit(daily)
        future = model.make_future_dataframe(periods=7)
        forecast = model.predict(future)
        
        forecasted_dates = forecast[forecast['yhat'] > daily['y'].mean()]['ds'].dt.strftime('%Y-%m-%d').tolist()
        alerts.append({
            "ReflexiveIP": ip,
            "ForecastedHighRiskDates": forecasted_dates
        })
    return alerts
