from sklearn.ensemble import IsolationForest
from src.config import CONFIG
import pandas as pd

def detect_anomalies(df):
    anomalies_list = []

    for stype in CONFIG['session_type_analysis']:
        df_type = df[df['Session Type'] == stype].copy()

        features = ['AvgJitter', 'AvgRoundTripTime', 'AvgPacketLoss']  # Common features for both

        X = df_type[features].fillna(0)
        model = IsolationForest(contamination=0.05, random_state=42)
        df_type['Anomaly'] = model.fit_predict(X)
        df_type = df_type[df_type['Anomaly'] == -1]
        anomalies_list.append(df_type)

    return pd.concat(anomalies_list, ignore_index=True)
