def get_network_type_counts(series):
    counts = {'Wired': 0, 'Wifi': 0, 'Unknown': 0}
    for val in series.dropna():
        if val in ['Wired', 'Wifi']:
            counts[val] += 1
        else:
            counts['Unknown'] += 1
    return counts
