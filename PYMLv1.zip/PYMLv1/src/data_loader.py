import pandas as pd
from sqlalchemy import create_engine
from src.config import CONFIG

def load_data():
    if CONFIG['input_source'] == 'csv':
        df = pd.read_csv(CONFIG['csv_path'], parse_dates=['Date', 'Start Time', 'End Time'])
    elif CONFIG['input_source'] == 'sql':
        engine = create_engine(CONFIG['sql']['connection_string'])
        query = f"SELECT * FROM {CONFIG['sql']['table_name']}"
        df = pd.read_sql(query, engine)
    else:
        raise ValueError("Invalid input source in config.")

    df = df[df['Session Type'].isin(CONFIG['session_type_analysis'])]
    return df
