import json
from src.utils import get_network_type_counts
from src.config import CONFIG
import pandas as pd

def generate_alerts(anomalies_df):
    alerts = []

    for ip, group in anomalies_df.groupby(
        lambda x: group_by_ip(anomalies_df.iloc[x]), sort=False
    ):
        first_conn = get_network_type_counts(group['First Network Connection Detail'])
        second_conn = get_network_type_counts(group['Second Network Connection Detail'])

        alert = {
            "ReflexiveIP": ip,
            "TotalAnomalies_Last30Days": len(group),
            "AffectedSessionTypeCounts": group['Session Type'].value_counts().to_dict(),
            "UniqueFirstUPNs": group['First UPN'].dropna().unique().tolist(),
            "UniqueSecondUPNs": group['Second UPN'].dropna().unique().tolist(),
            "FirstNetworkConnectionType": first_conn,
            "SecondNetworkConnectionType": second_conn,
            "AvgJitter_Last30Days": round(group['AvgJitter'].mean(), 2),
            "AvgRTT_Last30Days": round(group['AvgRoundTripTime'].mean(), 2),
            "AvgPacketLoss_Last30Days": round(group['AvgPacketLoss'].mean(), 2)
        }
        alerts.append(alert)
    return alerts

def group_by_ip(row):
    if row['Session Type'] == 'Conf':
        return row['Second Reflexive Local IP Network']
    else:  # P2P
        return row['First Reflexive Local IP Network'] if pd.notnull(row['First Reflexive Local IP Network']) else row['Second Reflexive Local IP Network']

def save_alerts(alerts, output_file):
    with open(output_file, 'w') as f:
        json.dump(alerts, f, indent=4)
