CONFIG = {
    "input_source": "csv",  # "csv" or "sql"
    "csv_path": "data/sample_input.csv",
    "session_type_analysis": ["P2P", "Conf"],  # Analyze both types

    "sql": {
        "connection_string": "mysql+pymysql://user:password@localhost/dbname",
        "table_name": "teams_call_data"
    }
}
