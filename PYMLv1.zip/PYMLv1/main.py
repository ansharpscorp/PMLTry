from src.data_loader import load_data
from src.anomaly_detection import detect_anomalies
from src.forecasting import forecast_anomalies
from src.alerting import generate_alerts, save_alerts
from src.clustering import perform_clustering

def main():
    df = load_data()
    df = perform_clustering(df)
    df.to_csv('output/clustered_output.csv', index=False)

    anomalies = detect_anomalies(df)
    anomalies.to_csv('output/anomalies.csv', index=False)

    alerts = generate_alerts(anomalies)
    save_alerts(alerts, 'output/enhanced_alerts.json')

    forecast_alerts = forecast_anomalies(df)
    save_alerts(forecast_alerts, 'output/forecast_alerts.json')

if __name__ == "__main__":
    main()