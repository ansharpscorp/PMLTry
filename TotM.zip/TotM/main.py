import argparse
import json
import os
from db.db_connection import get_engine, fetch_data
from features.feature_engineering import clean_and_engineer
from models.anomaly_detection import detect_anomalies
from models.xgboost_classifier import train_xgboost_classifier
from alerts.alert_generator import generate_detailed_alerts, generate_cluster_alerts

def main():
    parser = argparse.ArgumentParser(description="Teams CQD Anomaly Detection")
    parser.add_argument('--start_date', required=True, help='Start Date (YYYY-MM-DD)')
    parser.add_argument('--end_date', required=True, help='End Date (YYYY-MM-DD)')
    parser.add_argument('--output_dir', help='Output Directory')
    args = parser.parse_args()

    with open('config/config.json', 'r') as f:
        db_config = json.load(f)
    with open('config/business_rules.json', 'r') as f:
        business_rules = json.load(f)

    output_dir = args.output_dir or db_config.get('output_dir', 'alerts')
    os.makedirs(output_dir, exist_ok=True)

    engine = get_engine(
        db_config["server"],
        db_config["database"],
        db_config["username"],
        db_config["password"]
    )
    df = fetch_data(engine, args.start_date, args.end_date)

    session_type_filter = business_rules.get("session_type_filter", None)
    if session_type_filter:
        df = df[df["Session Type"] == session_type_filter]

    df = clean_and_engineer(df, business_rules)

    train_xgboost_classifier(df)

    anomalies = detect_anomalies(df, business_rules)

    generate_detailed_alerts(anomalies, business_rules, output_dir, args.start_date, args.end_date)
    generate_cluster_alerts(anomalies, business_rules, output_dir, args.start_date, args.end_date)
    print("Alerts generated at", output_dir)

if __name__ == "__main__":
    main()
