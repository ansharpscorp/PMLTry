import pandas as pd
import urllib
from sqlalchemy import create_engine

def get_engine(server, database, username, password):
    params = urllib.parse.quote_plus(
        f"Driver={{ODBC Driver 17 for SQL Server}};"
        f"Server={server};"
        f"Database={database};"
        "Authentication=ActiveDirectoryPassword;"
        f"UID={username};"
        f"PWD={password};"
        "Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;"
    )
    engine = create_engine(f"mssql+pyodbc:///?odbc_connect={params}", fast_executemany=True)
    return engine

def fetch_data(engine, start_date, end_date):
    query = f"""
    SELECT * FROM YourTableName
    WHERE Date >= '{start_date}' AND Date <= '{end_date}'
    """
    df = pd.read_sql(query, engine)
    return df
