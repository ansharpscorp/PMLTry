import ipaddress
import pandas as pd

def ipv4_to_subnet(ip):
    try:
        net = ipaddress.IPv4Interface(ip + '/24').network
        return str(net)
    except Exception:
        return "Unknown"

def map_vdi_mode(val):
    if pd.isnull(val):
        return "Unknown"
    val = str(val)
    if val.startswith("11") or val.startswith("21"):
        return "VDI 1.0"
    elif val.startswith("22"):
        return "VDI 2.0"
    else:
        return "Unknown"

def parse_vdi_is_optimized(vdi_mode, is_optimized_col):
    if pd.isnull(is_optimized_col):
        return "Unknown"
    vdi_mode = str(vdi_mode)
    is_optimized_col = str(is_optimized_col)
    if vdi_mode == "VDI 1.0":
        if is_optimized_col == "Optimized":
            return "Optimized"
        elif is_optimized_col == "Not Optimized":
            return "Not Optimized"
        else:
            return "Unknown"
    elif vdi_mode == "VDI 2.0":
        if is_optimized_col == "VDI 2.0 Optimized":
            return "Optimized"
        elif is_optimized_col == "VDI 2.0 Not Optimized":
            return "Not Optimized"
        else:
            return "Unknown"
    return "Unknown"
