teams_cqd_anomaly/
├── config/
│   └── business_rules.json
├── data/
│   └── (empty: for future artifacts, if any)
├── db/
│   └── db_connection.py
├── features/
│   └── feature_engineering.py
├── models/
│   ├── anomaly_detection.py
│   ├── feedback_analysis.py
│   └── time_series_pattern.py
├── alerts/
│   └── alert_generator.py
├── utils/
│   └── utils.py
├── main.py
├── requirements.txt
└── README.md
