import numpy as np
from utils.utils import ipv4_to_subnet, map_vdi_mode, parse_vdi_is_optimized

def clean_and_engineer(df, business_rules):
    # Fill nulls for numeric columns
    fill_zero_cols = [
        "Total Stream Count", "Audio Stream Count", "Audio Poor Stream Count", "Video Stream Count",
        "Video Poor Stream Count", "Total CDR Available Stream Count", "Total Call Setup Failed Stream Count",
        "Total Call Setup Succeeded Stream Count", "Total Call Dropped Stream Count", "Total Media Failed Stream Count",
        "Avg Jitter", "Avg Jitter Max", "Avg Round Trip", "Avg Round Trip Max", "Avg Packet Loss Rate",
        "Avg Packet Loss Rate Max", "Avg Overall Avg Network MOS", "Avg Packet Utilization"
    ]
    for col in fill_zero_cols:
        if col in df.columns:
            df[col] = df[col].fillna(0)

    # Normalize Network Connection Details
    for col in ["First Network Connection Detail", "Second Network Connection Detail"]:
        df[col] = df[col].replace({None: "Unknown", "": "Unknown"}).fillna("Unknown")
        df[col] = df[col].apply(lambda x: x if x in ["Wired", "Wifi", "MobileBB"] else "Unknown")

    # Set ClassifiedPoorCall if null and Audio Poor Stream Count or Video Stream Count is 1
    mask = ((df["Audio Poor Stream Count"] == 1) | (df["Video Stream Count"] == 1)) & (df["ClassifiedPoorCall"].isnull())
    df.loc[mask, "ClassifiedPoorCall"] = 1

    # Create percentage columns
    def safe_div(a, b):
        return np.where(b == 0, 0, a / b * 100)

    df["Audio Poor Percentage"] = safe_div(df["Audio Poor Stream Count"], df["Audio Stream Count"])
    df["Video Poor Percentage"] = safe_div(df["Video Poor Stream Count"], df["Video Stream Count"])
    df["Call Dropped Percentage"] = safe_div(df["Total Call Dropped Stream Count"], df["Total Stream Count"])
    df["Setup Failure Percentage"] = safe_div(df["Total Call Setup Failed Stream Count"],
                                             df["Total Call Setup Failed Stream Count"] + df["Total Call Setup Succeeded Stream Count"])

    # VDI Mode and Optimization columns (for both First and Second)
    for i in ["First", "Second"]:
        mode_col = f"{i} Client VDI Mode"
        vdi_col = f"{i} VDI Mode"
        is_opt_col = f"{i} Client VDI Is Optimized"
        vdi_opt_col = f"{i} VDI Is Optimized"

        df[vdi_col] = df[mode_col].apply(map_vdi_mode)
        df[vdi_opt_col] = df.apply(lambda row: parse_vdi_is_optimized(row[vdi_col], row[is_opt_col]), axis=1)
        # For analysis, add a binary column for not optimized
        df[f"{i} VDI Not Optimized"] = df[vdi_opt_col].apply(lambda x: 1 if x == "Not Optimized" else 0)

    # Subnet filling if blank and IPv4 present
    for i in ["First", "Second"]:
        subnet_col = f"{i} Subnet"
        ip_col = f"{i} IP Address"
        mask_subnet_null = (df[subnet_col].isnull() | (df[subnet_col] == "")) & df[ip_col].notnull()
        df.loc[mask_subnet_null, subnet_col] = df.loc[mask_subnet_null, ip_col].apply(ipv4_to_subnet)
        df[subnet_col] = df[subnet_col].fillna("Unknown")

    return df
