from sklearn.ensemble import IsolationForest

def detect_anomalies(df, business_rules):
    features = [
        "Avg Jitter", "Avg Jitter Max", "Avg Round Trip", "Avg Round Trip Max", "Avg Packet Loss Rate",
        "Avg Packet Loss Rate Max", "Audio Poor Percentage", "Video Poor Percentage", "Call Dropped Percentage"
    ]
    df_features = df[features].fillna(0)
    clf = IsolationForest(n_estimators=100, contamination=0.01, random_state=42)
    df['anomaly_score'] = clf.fit_predict(df_features)
    anomalies = df[df['anomaly_score'] == -1].copy()

    # Anomaly Reasoning
    def get_reason(row):
        if row["Avg Jitter Max"] - row["Avg Jitter"] > business_rules["jitter_threshold"]:
            return "Jitter Spike"
        elif row["Avg Round Trip Max"] - row["Avg Round Trip"] > business_rules["round_trip_threshold"]:
            return "Round Trip Spike"
        elif row["Avg Packet Loss Rate Max"] - row["Avg Packet Loss Rate"] > business_rules["packet_loss_threshold"]:
            return "Packet Loss Spike"
        elif row.get("Is Media Error", 0) == 1 or row.get("Total Media Failed Stream Count", 0) > 0:
            return "Media Failure"
        else:
            return "Unknown"

    anomalies["Anomaly Reason"] = anomalies.apply(get_reason, axis=1)
    return anomalies
