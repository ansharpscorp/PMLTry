def analyze_feedback(df):
    fb_issues = []
    for _, row in df.iterrows():
        if row.get("Second Feedback Rating Poor Count", 0) > 0:
            fb_issues.append({
                "Second Reflexive Local IP Network": row.get("Second Reflexive Local IP Network"),
                "Second Subnet": row.get("Second Subnet"),
                "Second UPN": row.get("Second UPN"),
                "Feedback Issue": row.get("Second Feedback Text", "No Text"),
                "Poor Feedback Count": row.get("Second Feedback Rating Poor Count", 0)
            })
    return fb_issues
