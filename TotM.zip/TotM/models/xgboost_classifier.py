import xgboost as xgb
from sklearn.model_selection import train_test_split
import pandas as pd

def prepare_classification_data(df):
    features = [
        "Avg Jitter", "Avg Jitter Max", "Avg Round Trip", "Avg Round Trip Max",
        "Avg Packet Loss Rate", "Avg Packet Loss Rate Max",
        "Audio Poor Percentage", "Video Poor Percentage", "Call Dropped Percentage",
        "First VDI Not Optimized", "Second VDI Not Optimized",
        "First Network Connection Detail", "Second Network Connection Detail",
        "Media Type"
    ]
    df_encoded = pd.get_dummies(df[features], columns=[
        "First Network Connection Detail", "Second Network Connection Detail", "Media Type"
    ], dummy_na=True)
    X = df_encoded
    y = df["ClassifiedPoorCall"].fillna(0).astype(int)
    return X, y

def train_xgboost_classifier(df):
    X, y = prepare_classification_data(df)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    clf = xgb.XGBClassifier(objective="binary:logistic", random_state=42, use_label_encoder=False, eval_metric="logloss")
    clf.fit(X_train, y_train)
    score = clf.score(X_test, y_test)
    print(f"XGBoost Classification Accuracy: {score:.3f}")
    feat_imp = pd.DataFrame({
        "feature": X.columns,
        "importance": clf.feature_importances_
    }).sort_values("importance", ascending=False)
    print("Top XGBoost Feature Importances:")
    print(feat_imp.head(10))
    return clf, feat_imp
