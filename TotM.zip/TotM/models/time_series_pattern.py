from prophet import Prophet

def pattern_using_prophet(df, date_col="Date", y_col="anomaly_count"):
    data = df.groupby(date_col).size().reset_index(name='anomaly_count')
    data.rename(columns={date_col: "ds", "anomaly_count": "y"}, inplace=True)
    model = Prophet(daily_seasonality=True, yearly_seasonality=True)
    model.fit(data)
    future = model.make_future_dataframe(periods=14)
    forecast = model.predict(future)
    return forecast[["ds", "yhat", "yhat_lower", "yhat_upper"]]
