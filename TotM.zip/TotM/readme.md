# Teams CQD Anomaly Detection

End-to-end solution for Microsoft Teams CQD anomaly and pattern analysis, including:
- Isolation Forest & XGBoost models
- Configurable business rules
- Per-user and cluster-level alerts for Power BI

## Setup

1. Fill `config/config.json` and `business_rules.json`
2. `pip install -r requirements.txt`
3. Run:

```bash
python main.py --start_date 2024-06-01 --end_date 2024-06-20
