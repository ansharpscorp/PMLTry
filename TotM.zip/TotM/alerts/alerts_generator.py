import pandas as pd
from datetime import timedelta
from collections import Counter

def generate_detailed_alerts(df, business_rules, output_dir, start_date, end_date):
    df['Date'] = pd.to_datetime(df['Date']).dt.date
    group = df.groupby(['Date', 'Second Reflexive Local IP Network'])
    rows = []
    for (date, ip), subdf in group:
        if subdf['Second UPN'].nunique() > business_rules['user_threshold'] and subdf['Second Subnet'].nunique() > business_rules['subnet_threshold']:
            for _, row in subdf.iterrows():
                rows.append({
                    'Date': date,
                    'Reflexive IP': ip,
                    'Subnet': row['Second Subnet'],
                    'UPN': row['Second UPN'],
                    'Conference Id': row['Conference Id'],
                    'Media Type': row['Media Type'],
                    'Stream Direction': row['Stream Direction'],
                    'Anomaly Reason': row['Anomaly Reason'],
                    'Avg Jitter': row['Avg Jitter'],
                    'Avg Jitter Max': row['Avg Jitter Max'],
                    'Avg Round Trip': row['Avg Round Trip'],
                    'Avg Round Trip Max': row['Avg Round Trip Max'],
                    'Avg Packet Loss Rate': row['Avg Packet Loss Rate'],
                    'Avg Packet Loss Rate Max': row['Avg Packet Loss Rate Max'],
                    'Avg Overall Avg Network MOS': row.get('Avg Overall Avg Network MOS', 0),
                    'Connection Type': row['Second Network Connection Detail'],
                    'VDI Version': row['Second VDI Mode'],
                    'VDI Is Optimized': row['Second VDI Is Optimized'],
                    'Device Name': row['Second Capture Dev Name'],
                    'Device Issue Identified': "Yes" if row.get('Device Issue', 0) else "No",
                    'Is Media Error': row.get('Is Media Error', 0),
                    'Poor Feedback Count': row.get('Second Feedback Rating Poor Count', 0),
                    'Poor Feedback Text': row.get('Second Feedback Text', ''),
                    'Start Time': row['Start Time'],
                    'End Time': row['End Time'],
                    'Remediation Suggestion': business_rules["recommendations"].get(row['Anomaly Reason'], "")
                })
    alert_df = pd.DataFrame(rows)
    alert_df.to_csv(f"{output_dir}/detailed_alerts_{start_date}_to_{end_date}.csv", index=False)
    return alert_df

def generate_cluster_alerts(df, business_rules, output_dir, start_date, end_date):
    rows = []
    device_issue_threshold = business_rules.get('device_issue_threshold', 0.3)
    df['Date'] = pd.to_datetime(df['Date']).dt.date
    cluster_groups = df.groupby(['Date', 'Second Reflexive Local IP Network', 'Second Subnet', 'Media Type', 'Stream Direction'])
    for group_keys, subdf in cluster_groups:
        upns = subdf['Second UPN'].nunique()
        subnets = subdf['Second Subnet'].nunique()
        if upns > business_rules['user_threshold'] and subnets > business_rules['subnet_threshold']:
            top_device, top_device_count = Counter(subdf['Second Capture Dev Name']).most_common(1)[0]
            percent_top_device = top_device_count / upns if upns else 0
            device_issue_identified = "Yes ({:.1f}%)".format(percent_top_device * 100) if percent_top_device >= device_issue_threshold else "No ({:.1f}%)".format(percent_top_device * 100)
            not_optimized_vdi = subdf['Second VDI Not Optimized'].mean()  # % not optimized
            rows.append({
                'Date': group_keys[0],
                'Reflexive IP': group_keys[1],
                'Subnet': group_keys[2],
                'Media Type': group_keys[3],
                'Stream Direction': group_keys[4],
                'Num UPNs Impacted': upns,
                'Num Subnets Impacted': subnets,
                'Num Conferences Impacted': subdf['Conference Id'].nunique(),
                'Num Conferences >100': sum(subdf.groupby('Conference Id')['Second UPN'].nunique() > business_rules['conference_user_threshold']),
                'Main Issue Time Window': f"{subdf['Start Time'].min()}-{subdf['End Time'].max()}",
                'Top Anomaly Reason': subdf['Anomaly Reason'].mode()[0],
                'Top Deviation Metric': f"Jitter Max-Avg: {subdf['Avg Jitter Max'].max() - subdf['Avg Jitter'].mean():.2f}",
                'Avg Jitter': subdf['Avg Jitter'].mean(),
                'Max Jitter': subdf['Avg Jitter Max'].max(),
                'Avg RTT': subdf['Avg Round Trip'].mean(),
                'Max RTT': subdf['Avg Round Trip Max'].max(),
                'Avg Packet Loss': subdf['Avg Packet Loss Rate'].mean(),
                'Max Packet Loss': subdf['Avg Packet Loss Rate Max'].max(),
                'Avg Overall Avg Network MOS': subdf['Avg Overall Avg Network MOS'].mean(),
                'Top VDI Version': subdf['Second VDI Mode'].mode()[0],
                '% Not Optimized VDI': "{:.1f}".format(not_optimized_vdi * 100),
                'Top Connection Type': subdf['Second Network Connection Detail'].mode()[0],
                'Top Device': top_device,
                'Top Device % of UPNs': "{:.1f}".format(percent_top_device * 100),
                'Device Issue Identified': device_issue_identified,
                'Num Media Errors': subdf['Is Media Error'].sum(),
                'Remediation Suggestion': business_rules["recommendations"].get(subdf['Anomaly Reason'].mode()[0], "")
            })
    alert_df = pd.DataFrame(rows)
    alert_df.to_csv(f"{output_dir}/cluster_alerts_{start_date}_to_{end_date}.csv", index=False)
    return alert_df
