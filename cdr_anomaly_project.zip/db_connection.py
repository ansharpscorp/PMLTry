import json
from sqlalchemy import create_engine

def get_synapse_engine(config_path="config.json"):
    cfg = json.load(open(config_path))["synapse"]
    drv = cfg['driver'].replace(' ', '+')
    conn_str = (
        f"mssql+pyodbc://{cfg['username']}:{cfg['password']}@"
        f"{cfg['server']}/{cfg['database']}?driver={drv}"
    )
    return create_engine(conn_str)
