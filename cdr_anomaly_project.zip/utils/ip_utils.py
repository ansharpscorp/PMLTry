import ipaddress

def extract_subnet(ip):
    try:
        return str(ipaddress.ip_network(ip + '/24', strict=False))
    except:
        return 'Unknown'
