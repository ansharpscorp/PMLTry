import os
import json
import pandas as pd
from forecasting import forecast_anomalies

class AlertGenerator:
    def __init__(self, rules_path="business_rules.json", config_path="config.json"):
        self.rules = json.load(open(rules_path))
        out_cfg = json.load(open(config_path))["output"]
        os.makedirs(out_cfg["alerts_folder"], exist_ok=True)
        os.makedirs(out_cfg["log_folder"], exist_ok=True)
        self.alerts_folder = out_cfg["alerts_folder"]

    def generate(self, df):
        alerts = {}
        for rip, df_rip in df.groupby('Second Reflexive Local IP Network'):
            subnets = {}
            for subnet, df_sub in df_rip.groupby('Second Subnet'):
                users = {}
                for upn, df_user in df_sub.groupby('Second UPN'):
                    users[upn] = {
                        "media_breakdown": df_user['Media Type'].value_counts().to_dict(),
                        "network_breakdown": df_user['Second Network Connection Detail'].value_counts().to_dict(),
                        "vdi_breakdown": df_user['Second VDI Version'].value_counts().to_dict(),
                        "feedback": {
                            "rating": int(df_user['Second Feedback Rating Poor Count'].sum()),
                            "sentiment": float(df_user['feedback_sentiment'].mean())
                        }
                    }
                subnets[subnet] = {"user_count": len(users), "users": users}

            total_users = df_rip['Second UPN'].nunique()
            total_subnets = len(subnets)
            if total_users < self.rules["alert_user_count_threshold"] or total_subnets < self.rules["alert_subnet_count_threshold"]:
                continue

            spike_events = self._detect_spikes(df_rip)

            daily = df_rip.assign(date=pd.to_datetime(df_rip['Date'])).groupby('date').size().reset_index(name='y')
            daily = daily.rename(columns={'date': 'ds'})
            fc = forecast_anomalies(daily)

            alerts[rip] = {
                "total_subnets": total_subnets,
                "total_users": total_users,
                "subnets": subnets,
                "spike_events": spike_events,
                "forecast": {
                    "next_issue_dates": fc[fc['yhat'] > fc['yhat_upper']].ds.dt.strftime('%Y-%m-%d').tolist()
                },
                "suggestions": self._derive_suggestions(df_rip)
            }

        out_file = os.path.join(self.alerts_folder, "Alerts_reflexiveip.json")
        with open(out_file, 'w') as f:
            json.dump(alerts, f, indent=2)
        print(f"Alerts written to {out_file}")

    def _derive_suggestions(self, df_slice):
        sugg = []
        if df_slice['Avg Jitter Max'].max() > self.rules["jitter_threshold"]:
            sugg.append(self.rules["suggestions"]["High Jitter"])
        if df_slice['Avg Round Trip Max'].max() > self.rules["round_trip_threshold"]:
            sugg.append(self.rules["suggestions"]["High Round Trip"])
        if df_slice['Avg Packet Loss Rate Max'].max() > self.rules["packet_loss_threshold"]:
            sugg.append(self.rules["suggestions"]["High Packet Loss"])
        if (df_slice['feedback_sentiment'] < self.rules["feedback_sentiment_threshold"]).any():
            sugg.append(self.rules["suggestions"]["Negative Feedback"])
        return list(set(sugg))

    def _detect_spikes(self, df):
        spikes = {}
        spikes["jitter"] = df[df['Avg Jitter Max'] > self.rules["jitter_threshold"]]['Date'].unique().tolist()
        spikes["round_trip"] = df[df['Avg Round Trip Max'] > self.rules["round_trip_threshold"]]['Date'].unique().tolist()
        spikes["packet_loss"] = df[df['Avg Packet Loss Rate Max'] > self.rules["packet_loss_threshold"]]['Date'].unique().tolist()
        mfc = df['Total Media Failed Stream Count']
        threshold_mfc = mfc.mean() + 2 * mfc.std()
        spikes["media_failures"] = df[df['Total Media Failed Stream Count'] > threshold_mfc]['Date'].unique().tolist()
        cdc = df['Total Call Dropped Stream Count']
        threshold_cdc = cdc.mean() + 2 * cdc.std()
        spikes["call_drops"] = df[df['Total Call Dropped Stream Count'] > threshold_cdc]['Date'].unique().tolist()
        return spikes
