# Teams Call Quality Anomaly Detection
Run main.py with `--start_date` and `--end_date`.
Check `config/` for configuration and thresholds.