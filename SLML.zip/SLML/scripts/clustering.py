from sklearn.cluster import KMeans
import sqlite3

def cluster_subnets(df, config):
    svc = df.groupby("Second Reflexive Local IP Network")["Total Stream Count"].sum().reset_index()
    n = config["rules"]["Clustering"]["KMeansClusters"]
    svc["ClusterID"] = KMeans(n_clusters=n, random_state=42).fit_predict(svc[["Total Stream Count"]])
    conn = sqlite3.connect("output/sqlite/anomaly_results.db")
    svc.to_sql("Top10Subnets", conn, if_exists="replace", index=False)
    conn.close()