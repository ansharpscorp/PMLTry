from sklearn.ensemble import IsolationForest

def detect_anomaly(df):
    X = df[["Avg Jitter", "Avg Packet Loss Rate"]]
    model = IsolationForest(contamination=0.05, random_state=42).fit(X)
    df["anomaly_flag"] = model.predict(X)
    return df[df["anomaly_flag"] == -1]