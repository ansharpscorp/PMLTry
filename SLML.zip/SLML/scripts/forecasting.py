import pandas as pd
from prophet import Prophet
import sqlite3

def forecast(df, config):
    ts = df.groupby("Date")["anomaly_flag"].count().reset_index().rename(columns={"anomaly_flag": "y", "Date": "ds"})
    m = Prophet()
    m.fit(ts)
    future = m.make_future_dataframe(periods=config["rules"]["ForecastDays"])
    res = m.predict(future)[["ds", "yhat"]]
    conn = sqlite3.connect("output/sqlite/anomaly_results.db")
    res.to_sql("Forecast", conn, if_exists="replace", index=False)
    conn.close()