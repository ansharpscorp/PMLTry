import xgboost as xgb
from sklearn.preprocessing import LabelEncoder

class PoorCallPredictor:
    def __init__(self):
        self.encoders = {}
        self.model = None

    def train(self, df):
        df_train = df[df["ClassifiedPoorCall"].notnull()].copy()
        features = ["Media Type", "First Network Connection Detail",
                    "Avg Jitter", "Avg Round Trip", "Avg Packet Loss Rate",
                    "Total Stream Count", "Call Drop Percentage", "Call Setup Failed Percentage",
                    "Stream Direction"]
        for col in ["Media Type", "First Network Connection Detail", "Stream Direction"]:
            le = LabelEncoder()
            df_train[col] = le.fit_transform(df_train[col].astype(str))
            self.encoders[col] = le

        X = df_train[features]
        y = df_train["ClassifiedPoorCall"].astype(int)
        self.model = xgb.XGBClassifier(use_label_encoder=False, eval_metric="logloss")
        self.model.fit(X, y)

    def predict(self, df):
        df_pred = df.copy()
        for col, le in self.encoders.items():
            df_pred[col] = le.transform(df_pred[col].astype(str))
        df_pred["XGB_PoorCall_Prob"] = self.model.predict_proba(df_pred[self.encoders.keys()])[:,1]
        return df_pred