import sqlite3, json
from datetime import datetime

def save_alerts(anom_df, full_df):
    dt = datetime.now().strftime("%Y-%m-%d")
    for idx, row in anom_df.iterrows():
        original = full_df.loc[row.name]
        alert = {
            "date": dt,
            "region": original["Region"],
            "subnet": original["Second Reflexive Local IP Network"],
            "upns_affected": int(original["Second UPN"]),
            "anomaly_score": int(row["anomaly_flag"]),
            "xgb_poor_call_prob": float(original["XGB_PoorCall_Prob"])
        }
        path = f"output/json_alerts/alert_{idx}_{dt}.json"
        with open(path, "w") as f:
            json.dump(alert, f, indent=4)

def save_sqlite(anom_df, full_df):
    conn = sqlite3.connect("output/sqlite/anomaly_results.db")
    full_df.to_sql("AnomalySummary", conn, if_exists="replace", index=False)
    conn.close()