import pandas as pd, json
from .db_utils import get_synapse_conn

def load_rules(path='config/business_rules.json'):
    return json.load(open(path))

def get_threshold(rules, region, session_type):
    dflt = rules["AnomalyThresholds"]["Default"]["AvgJitter"]
    r = rules["AnomalyThresholds"]["RegionSpecific"].get(region, {}).get("AvgJitter", dflt)
    s = rules["AnomalyThresholds"]["SessionTypeSpecific"].get(session_type, {}).get("AvgJitter", dflt)
    return min(r, s)

def load_data_from_synapse(config):
    conn = get_synapse_conn(
        config["synapse_server"], config["synapse_db"],
        config["synapse_user"], config["synapse_pwd"]
    )
    df = pd.read_sql("SELECT * FROM CQD_CallRecords", conn)
    rf = pd.read_sql("SELECT * FROM Reflexive_Lookup", conn)
    sb = pd.read_sql("SELECT * FROM Subnet_Lookup", conn)
    conn.close()
    return df.merge(rf, left_on='Second Reflexive Local IP Network', right_on='ReflexiveIP', how='left') \
             .merge(sb, left_on='Second Reflexive Local IP Network', right_on='Subnet', how='left')

def prepare_data(config):
    df = load_data_from_synapse(config)
    df.fillna(0, inplace=True)
    df["JitterThreshold"] = df.apply(
        lambda x: get_threshold(config["rules"], x["Region"], x["Session Type"]),
        axis=1
    )
    return df