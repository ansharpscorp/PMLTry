from scripts import data_prep, anomaly_iso, clustering, forecasting, reporting
from scripts.xgboost_model import PoorCallPredictor
import json, os

config = json.load(open("config/business_rules.json"))
config.update({
    "synapse_server": "<server>",
    "synapse_db": "<db>",
    "synapse_user": "<user>",
    "synapse_pwd": "<pw>"
})

os.makedirs("output/json_alerts", exist_ok=True)
os.makedirs("output/sqlite", exist_ok=True)

df = data_prep.prepare_data(config)
anom = anomaly_iso.detect_anomaly(df)

predictor = PoorCallPredictor()
predictor.train(df)
df = predictor.predict(df)

reporting.save_alerts(anom, df)
reporting.save_sqlite(anom, df)
clustering.cluster_subnets(anom, config)
forecasting.forecast(anom, config)

print("Pipeline executed with XGBoost integration!")