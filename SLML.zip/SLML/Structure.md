CQD_Service_ML_Project/
│
├── config/
│   └── business_rules.json
│
├── data/
│   └── (optional sample CSVs)
│
├── output/
│   ├── json_alerts/             # Individual JSON alert files
│   └── sqlite/
│       └── anomaly_results.db   # SQLite DB for Power BI
│
├── scripts/
│   ├── __init__.py
│   ├── db_utils.py              # Synapse connection utilities
│   ├── data_prep.py
│   ├── anomaly_iso.py
│   ├── clustering.py
│   ├── forecasting.py
│   └── reporting.py
│
├── main.py
└── requirements.txt
