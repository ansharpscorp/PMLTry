from config import INPUT_FILE, OUTPUT_FILE
from utils import load_input_csv, save_output_csv
from summarizer import generate_summary

def main():
    df = load_input_csv(INPUT_FILE)
    summary_df = generate_summary(df)
    save_output_csv(summary_df, OUTPUT_FILE)

if __name__ == "__main__":
    main()
