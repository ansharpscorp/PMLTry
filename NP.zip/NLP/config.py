from pathlib import Path

INPUT_DIR = Path("input")
OUTPUT_DIR = Path("output")
INPUT_FILE = INPUT_DIR / "model_output.csv"
OUTPUT_FILE = OUTPUT_DIR / "summary.csv"