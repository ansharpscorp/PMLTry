import pandas as pd

def load_input_csv(filepath):
    df = pd.read_csv(filepath, parse_dates=["Date"])
    df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
    df.dropna(subset=['Date', 'Reflexive IP', 'UPN', 'Subnet', 'Media Type', 'Anomaly Reason'], inplace=True)
    return df

def save_output_csv(df, filepath):
    df.to_csv(filepath, index=False)
    print(f"✅ Output saved to {filepath}")