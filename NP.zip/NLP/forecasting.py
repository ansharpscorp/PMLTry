from prophet import Prophet

def generate_forecast(df_group):
    ts = df_group.groupby('Date').size().reset_index(name='Anomalies')
    ts.rename(columns={'Date': 'ds', 'Anomalies': 'y'}, inplace=True)

    if len(ts) < 5:
        return []

    model = Prophet(daily_seasonality=True)
    model.fit(ts)
    future = model.make_future_dataframe(periods=7)
    forecast = model.predict(future)
    return forecast[['ds', 'yhat']].tail(7)