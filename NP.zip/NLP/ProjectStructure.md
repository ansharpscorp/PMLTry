anomaly_summary_project/
│
├── input/
│   └── model_output.csv         # <-- Your raw input data file
│
├── output/
│   └── summary.csv              # <-- Final output with summaries
│
├── main.py                      # Main entry point to run the pipeline
├── forecasting.py               # Forecasting logic using Prophet
├── summarizer.py                # Story generation & CSV writer
├── utils.py                     # Shared helper functions
├── config.py                    # Folder paths and settings
└── requirements.txt             # Libraries required
