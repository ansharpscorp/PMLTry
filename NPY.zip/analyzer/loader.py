import pandas as pd
from datetime import datetime, timedelta

def load_data(config):
    csv_path = config["input_csv"]
    cols = config["columns"]

    df = pd.read_csv(csv_path, parse_dates=[cols["date"]])
    df = df[df[cols["date"]] >= datetime.now() - timedelta(days=config["forecast_days"] * 2)]
    return df
