import pandas as pd
from prophet import Prophet

def build_detailed_forecast(df, config):
    cols = config["columns"]
    forecast_days = config["forecast_days"]
    output_rows = []

    grouped = df.groupby([cols["reflexive_ip"], cols["subnet"], cols["upn"], cols["stream_direction"]])

    # Forecast once per Reflexive IP
    forecast_cache = {}

    for (ip, subnet, upn, direction), group_df in grouped:
        anomaly_summary = group_df[cols["anomaly_reason"]].value_counts().to_dict()
        total_alerts = group_df[cols["conference_id"]].count()

        if ip not in forecast_cache:
            df_count = (
                df[df[cols["reflexive_ip"]] == ip]
                .groupby(cols["date"])
                .agg(alerts=(cols["conference_id"], 'count'))
                .reset_index()
                .rename(columns={cols["date"]: "ds", "alerts": "y"})
            )

            if len(df_count) >= 2:
                model = Prophet(daily_seasonality=True)
                model.fit(df_count)
                future = model.make_future_dataframe(periods=forecast_days)
                forecast = model.predict(future)[["ds", "yhat"]].tail(forecast_days)
                forecast["yhat"] = forecast["yhat"].round(1)
                forecast_cache[ip] = forecast
            else:
                forecast_cache[ip] = pd.DataFrame(columns=["ds", "yhat"])

        forecast_df = forecast_cache[ip]

        for _, row in forecast_df.iterrows():
            output_rows.append({
                "Reflexive IP": ip,
                "Subnet": subnet,
                "UPN": upn,
                "Stream Direction": direction,
                "Date": row["ds"].date().isoformat(),
                "Forecasted Alerts": row["yhat"],
                "Total Alerts": total_alerts,
                "Anomalies": anomaly_summary
            })

    return pd.DataFrame(output_rows)
