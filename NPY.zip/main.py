import json
from analyzer.loader import load_data
from analyzer.processor import build_detailed_forecast

with open("config.json") as f:
    config = json.load(f)

df = load_data(config)
detailed_forecast_df = build_detailed_forecast(df, config)
detailed_forecast_df.to_csv(config["output_summary_csv"], index=False)
print(f"✔ Detailed forecast saved to {config['output_summary_csv']}")
